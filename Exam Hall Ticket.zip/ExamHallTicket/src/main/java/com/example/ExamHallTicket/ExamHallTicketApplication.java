package com.example.ExamHallTicket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamHallTicketApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamHallTicketApplication.class, args);
	}
}
