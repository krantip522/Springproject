package com.example.ExamHallTicket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamHallTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
